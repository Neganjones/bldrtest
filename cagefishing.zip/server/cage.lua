-- Server-side cage management
local ActiveCages = {}

RegisterNetEvent('fishing:syncCage', function(cageData)
    local source = source
    
    -- Store cage data
    if not ActiveCages[source] then
        ActiveCages[source] = {}
    end
    
    table.insert(ActiveCages[source], {
        id = cageData.id,
        coords = cageData.coords,
        depth = cageData.depth,
        entity = nil,
        created = os.time(),
    })
end)

RegisterNetEvent('fishing:cageNetworkSync', function(netId, cageId, playerCoords)
    local source = source
    
    -- Validate cage ownership
    if ActiveCages[source] then
        for _, cage in ipairs(ActiveCages[source]) do
            if cage.id == cageId then
                cage.entity = netId
                break
            end
        end
    end
end)

-- Get all active cages
function GetActiveCages()
    return ActiveCages
end

-- Check if player can place cage
function CanPlaceCage(source)
    if not ActiveCages[source] then
        return true
    end
    return #ActiveCages[source] < Config.CageSettings.maxCagesPerPlayer
end

-- Remove cage from server
function RemoveActiveCage(source, cageId)
    if ActiveCages[source] then
        for i, cage in ipairs(ActiveCages[source]) do
            if cage.id == cageId then
                table.remove(ActiveCages[source], i)
                return true
            end
        end
    end
    return false
end

-- Cleanup on drop
AddEventHandler('playerDropped', function()
    local source = source
    ActiveCages[source] = nil
end)
