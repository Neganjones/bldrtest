local Leaderboards = require 'shared.leaderboards'
local QBCore = exports['qb-core']:GetCoreObject()

-- Update leaderboards on fish catch
RegisterNetEvent('deepseafishing:server:updateLeaderboards', function(fishType, rarity, weight, earnings)
    local src = source
    local player = QBCore.Functions.GetPlayer(src)
    if not player then return end
    
    local citizenId = player.PlayerData.citizenid
    local playerName = player.PlayerData.charinfo.firstname .. ' ' .. player.PlayerData.charinfo.lastname
    
    -- Update all leaderboard categories
    Leaderboards.UpdateEarnings(citizenId, playerName, earnings)
    Leaderboards.UpdateCatches(citizenId, playerName, 1)
    Leaderboards.UpdateHeaviestFish(citizenId, playerName, fishType, weight)
    Leaderboards.UpdateRarityRecords(citizenId, playerName, rarity)
end)

-- Sync leaderboards to client
RegisterNetEvent('deepseafishing:server:getLeaderboards', function(category, limit)
    local src = source
    limit = limit or 10
    
    local leaderboard = {}
    if category == 'earnings' then
        leaderboard = Leaderboards.GetTopEarners(limit)
    elseif category == 'catches' then
        leaderboard = Leaderboards.GetTopCatchers(limit)
    elseif category == 'heaviest' then
        leaderboard = Leaderboards.GetHeaviestFish(limit)
    elseif category == 'rarity' then
        leaderboard = Leaderboards.GetRarityRecords(limit)
    end
    
    TriggerClientEvent('deepseafishing:client:receiveLeaderboards', src, category, leaderboard)
end)

-- Get player ranking
RegisterNetEvent('deepseafishing:server:getPlayerRanking', function(category)
    local src = source
    local player = QBCore.Functions.GetPlayer(src)
    if not player then return end
    
    local citizenId = player.PlayerData.citizenid
    local ranking = 0
    local value = 0
    
    if category == 'earnings' then
        for i, entry in ipairs(Leaderboards.GetTopEarners(100)) do
            if entry.citizenId == citizenId then
                ranking = i
                value = entry.total_earnings
                break
            end
        end
    elseif category == 'catches' then
        for i, entry in ipairs(Leaderboards.GetTopCatchers(100)) do
            if entry.citizenId == citizenId then
                ranking = i
                value = entry.total_catches
                break
            end
        end
    elseif category == 'heaviest' then
        for i, entry in ipairs(Leaderboards.GetHeaviestFish(100)) do
            if entry.citizenId == citizenId then
                ranking = i
                value = entry.weight
                break
            end
        end
    elseif category == 'rarity' then
        for i, entry in ipairs(Leaderboards.GetRarityRecords(100)) do
            if entry.citizenId == citizenId then
                ranking = i
                value = entry.legendary_catches
                break
            end
        end
    end
    
    TriggerClientEvent('deepseafishing:client:receivePlayerRanking', src, category, ranking, value)
end)

-- Export for admin commands
function GetLeaderboardData(category, limit)
    limit = limit or 10
    if category == 'earnings' then
        return Leaderboards.GetTopEarners(limit)
    elseif category == 'catches' then
        return Leaderboards.GetTopCatchers(limit)
    elseif category == 'heaviest' then
        return Leaderboards.GetHeaviestFish(limit)
    elseif category == 'rarity' then
        return Leaderboards.GetRarityRecords(limit)
    end
end

exports('GetLeaderboardData', GetLeaderboardData)
