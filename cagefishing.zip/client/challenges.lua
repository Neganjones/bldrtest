-- Daily Challenges UI System
local playerChallenges = {}
local challengeUI = false

-- Format challenge for display
local function FormatChallengeForDisplay(challenge)
    local progress = challenge.progress
    local goal = challenge.goal
    local percentage = math.floor((progress / goal) * 100)
    
    return {
        title = challenge.name,
        description = challenge.description,
        progress = progress,
        goal = goal,
        percentage = percentage,
        completed = challenge.completed,
        claimed = challenge.claimed,
        reward = challenge.reward,
        multiplier = challenge.multiplier,
    }
end

-- Show challenges menu
function ShowChallengesMenu()
    if not Config.DailyChallenges.enabled then
        lib.notify({
            title = 'Challenges',
            description = 'Daily challenges are disabled',
            type = 'info',
        })
        return
    end

    TriggerServerEvent('fishing:getChallenges')
    
    Wait(100)
    
    if not playerChallenges or next(playerChallenges) == nil then
        lib.notify({
            title = 'Challenges',
            description = 'Failed to load challenges',
            type = 'error',
        })
        return
    end

    local options = {}
    
    -- Add header
    table.insert(options, {
        header = '📊 Daily Fishing Challenges',
        isMenuHeader = true,
    })
    
    -- Add challenges
    for _, challenge in pairs(playerChallenges) do
        local status = ''
        if challenge.claimed then
            status = ' ✓ CLAIMED'
        elseif challenge.completed then
            status = ' ✓ COMPLETED'
        else
            status = ' ⏳ ' .. challenge.progress .. '/' .. challenge.goal
        end
        
        local description = challenge.description .. status
        
        table.insert(options, {
            header = challenge.name,
            txt = description,
            params = {
                event = 'fishing:selectChallenge',
                args = {
                    challengeId = challenge.id,
                    challenge = challenge,
                }
            }
        })
    end
    
    -- Add separator
    table.insert(options, {
        isMenuHeader = true,
    })
    
    -- Add close option
    table.insert(options, {
        header = '❌ Close',
        txt = 'Close challenges menu',
        params = {
            event = 'fishing:closeMenu',
        }
    })
    
    -- Display menu based on config
    if Config.Menus.style == 'qbcore' then
        exports['qb-menu']:openMenu(options)
    else
        -- ox_lib menu
        lib.showMenu('challengesMenu')
    end
end

-- Show challenge details
function ShowChallengeDetails(challenge)
    local progressBar = ''
    local filledBars = math.floor(challenge.percentage / 10)
    for i = 1, 10 do
        if i <= filledBars then
            progressBar = progressBar .. '█'
        else
            progressBar = progressBar .. '░'
        end
    end

    local content = string.format(
        '**Objective:** %s\n\n' ..
        '**Progress:** %d/%d (%d%%)\n' ..
        '%s\n\n' ..
        '**Reward:** $%d\n' ..
        '**Bonus Multiplier:** %.0f%%',
        challenge.description,
        challenge.progress,
        challenge.goal,
        challenge.percentage,
        progressBar,
        challenge.reward,
        (challenge.multiplier - 1) * 100
    )

    lib.alertDialog({
        header = challenge.name,
        content = content,
        centered = true,
        cancel = true,
        labels = {
            confirm = challenge.completed and not challenge.claimed and 'Claim Reward' or 'Ok',
            cancel = 'Close',
        }
    })

    if challenge.completed and not challenge.claimed then
        TriggerServerEvent('fishing:claimChallengeReward', challenge.id)
    end
end

-- Event listeners
RegisterNetEvent('fishing:receiveChallenges', function(challenges)
    playerChallenges = challenges
end)

RegisterNetEvent('fishing:challengeCompleted', function(challengeId, challengeName)
    lib.notify({
        title = '🎉 Challenge Complete!',
        description = challengeName .. ' completed!',
        type = 'success',
        duration = 5000,
    })
end)

RegisterNetEvent('fishing:challengeClaimed', function(challengeId)
    if playerChallenges[challengeId] then
        playerChallenges[challengeId].claimed = true
    end
end)

RegisterNetEvent('fishing:challengesReset', function()
    playerChallenges = {}
    lib.notify({
        title = '🔄 Daily Reset',
        description = 'Daily challenges have been reset!',
        type = 'info',
        duration = 5000,
    })
end)

-- Menu select event
RegisterNetEvent('fishing:selectChallenge', function(data)
    local challenge = data.challenge
    ShowChallengeDetails(challenge)
end)

-- Close menu event
RegisterNetEvent('fishing:closeMenu', function()
    exports['qb-menu']:closeMenu()
end)

-- Export functions
return {
    Show = ShowChallengesMenu,
    ShowDetails = ShowChallengeDetails,
}
