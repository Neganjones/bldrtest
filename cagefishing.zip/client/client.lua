local QBCore = exports['qb-core']:GetCoreObject()
local PlayerCages = {}
local CurrentMenu = nil
local IsFishing = false

local Notifications = require 'shared.notifications'
local TextUI = require 'client.textui'
local Challenges = require 'client.challenges'
local LeaderboardsUI = require 'client.leaderboards'

-- Wait for QBCore
Wait(100)

-- Main fishing menu
local function OpenFishingMenu(cageId)
    local cage = PlayerCages[cageId]
    if not cage then return end
    
    CurrentMenu = {
        {
            title = 'Fish Cage',
            description = 'Depth: ' .. cage.depth .. ' | Catches: ' .. cage.catches,
            icon = 'fa-solid fa-water',
            disabled = false,
        },
        {
            title = 'Cast Fishing Line',
            description = 'Attempt to catch fish at this depth',
            icon = 'fa-solid fa-hook',
            onSelect = function()
                CastFishingLine(cageId)
            end,
        },
        {
            title = 'View Fish Info',
            description = 'See what fish are available at this depth',
            icon = 'fa-solid fa-book',
            onSelect = function()
                ViewFishInfo(cage.depth)
            end,
        },
         {
             title = 'Retrieve Cage',
             description = 'Remove the cage and collect any remaining fish',
             icon = 'fa-solid fa-box',
             onSelect = function()
                 RetrieveCage(cageId)
             end,
         },
         {
             title = '🏆 Leaderboards',
             description = 'View top players and records',
             icon = 'fa-solid fa-trophy',
             onSelect = function()
                 LeaderboardsUI.DisplayLeaderboardMenu()
             end,
         },
     }
    
    lib.registerContext({
        id = 'fishing_menu_' .. cageId,
        title = 'Fishing Menu',
        options = CurrentMenu,
    })
    
    lib.showContext('fishing_menu_' .. cageId)
end

-- Cast fishing line with minigame
function CastFishingLine(cageId)
    local cage = PlayerCages[cageId]
    if not cage then return end
    
    if IsFishing then
        Notifications.Error('Fishing', 'You are already fishing!')
        return
    end
    
    IsFishing = true
    
    Notifications.Info('Fishing', 'Casting line...')
    
    -- Trigger server minigame
    TriggerServerEvent('fishing:startMinigame', cageId, cage.depth)
end

-- View available fish at depth
function ViewFishInfo(depth)
    local fishList = FishData.GetFishByDepth(depth)
    
    local options = {
        {
            title = 'Available Fish - ' .. Config.DepthRanges[depth].label,
            description = 'Fish available at this depth',
            icon = 'fa-solid fa-list',
            disabled = true,
        },
    }
    
    for _, fish in ipairs(fishList) do
        table.insert(options, {
            title = fish.label,
            description = 'Rarity: ' .. fish.rarity:upper() .. ' | $' .. fish.sellPrice .. ' | Catch: ' .. fish.minCatch .. '-' .. fish.maxCatch,
            icon = 'fa-solid fa-fish',
        })
    end
    
    table.insert(options, {
        title = 'Back',
        onSelect = function()
            lib.hideContext()
        end,
        icon = 'fa-solid fa-arrow-left',
    })
    
    lib.registerContext({
        id = 'fish_info_' .. depth,
        title = 'Fish Information',
        options = options,
    })
    
    lib.showContext('fish_info_' .. depth)
end

-- Retrieve cage
function RetrieveCage(cageId)
    lib.alertDialog({
        header = 'Retrieve Cage?',
        content = 'Are you sure you want to retrieve this cage? It will be removed.',
        centered = true,
        cancel = true,
        labels = {
            confirm = 'Yes',
            cancel = 'No',
        },
    })
    
    if not lib.alertDialog() then
        return
    end
    
    TriggerServerEvent('fishing:removeCage', cageId)
end

-- Event handlers
RegisterNetEvent('fishing:cagePlaced', function(cage)\n    PlayerCages[cage.id] = cage\n    \n    TextUI.Show('[E] - Fish Cage | Depth: ' .. cage.depth:upper(), 'fa-solid fa-water')
    
    -- Create zone for interaction\n    local point = lib.points.new({\n        coords = cage.coords,\n        distance = Config.CageSettings.interactionDistance,\n        onEnter = function()\n            TextUI.Show('[E] - Interact with Cage | Press E', 'fa-solid fa-hook')\n        end,\n        onExit = function()\n            TextUI.Hide()\n        end,
        nearby = function()
            if IsControlJustReleased(0, 38) then -- E key
                OpenFishingMenu(cage.id)
            end
        end,
    })
    
    cage.zone = point
end)

RegisterNetEvent('fishing:cageRemoved', function(cageId)\n    if PlayerCages[cageId] then\n        if PlayerCages[cageId].zone then\n            PlayerCages[cageId].zone:remove()\n        end\n        PlayerCages[cageId] = nil\n    end\n    TextUI.Hide()\nend)

RegisterNetEvent('fishing:fishCaught', function(fish, amount, reward)\n    IsFishing = false\n    \n    Notifications.Success('Catch Successful!', 'You caught ' .. amount .. 'x ' .. fish.label .. ' worth $' .. reward)\nend)

RegisterNetEvent('fishing:clientMinigame', function(cageId, depth)
    StartFishingMinigame(cageId, depth)
end)

-- Item usage for fishing cage
RegisterNetEvent('farming:interact', function(itemName)
    if itemName == 'fishing_cage' then
        OpenCageDepthMenu()
    end
end)

function OpenCageDepthMenu()
    local options = {}
    
    for depth, info in pairs(Config.DepthRanges) do
        table.insert(options, {
            title = info.label:upper(),
            description = info.description .. ' | Reward Multiplier: ' .. (Config.RewardMultipliers[depth] or 1.0) .. 'x',
            icon = 'fa-solid fa-water',
            onSelect = function()
                PlaceFishingCage(depth)
            end,
        })
    end
    
    table.insert(options, {
        title = 'Cancel',
        icon = 'fa-solid fa-times',
        onSelect = function()
            lib.hideContext()
        end,
    })
    
    lib.registerContext({
        id = 'cage_depth_menu',
        title = 'Select Cage Depth',
        options = options,
    })
    
    lib.showContext('cage_depth_menu')
end

-- Check if player is in a boat
function IsPlayerInBoat()
    local playerPed = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(playerPed, false)
    
    if vehicle == 0 then
        return false
    end
    
    local vehicleType = GetVehicleType(vehicle)
    -- Vehicle type 6 is for boats/jets
    return vehicleType == 6
end

-- Export functions
function PlaceFishingCage(depthType)
    if not IsPlayerInBoat() then
        Notifications.Error('Fishing', 'You must be in a boat to place a cage!')
        return
    end
    
    local playerCoords = GetEntityCoords(PlayerPedId())
    local isNearWater, waterZ = GetWaterHeight(playerCoords.x, playerCoords.y)
    
    if not isNearWater then
        Notifications.Error('Fishing', 'You must be near water to place a cage!')
        return
    end
    
    local cageCoords = vector3(playerCoords.x + 5, playerCoords.y + 5, waterZ - 5)
    
    TriggerServerEvent('fishing:placeCage', cageCoords, depthType)
end



-- Daily challenges command
lib.addCommand('challenges', {
    help = 'View your daily fishing challenges',
    restricted = false,
}, function(source, args, raw)
    Challenges.Show()
end)

-- Debug command
if Config.Debug then
    print('^2[Fishing] Client loaded^7')
end
