local Leaderboards = require 'shared.leaderboards'
local Notifications = require 'shared.notifications'
local Config = require 'shared.config'

local leaderboardData = {}
local playerRanking = {}

-- Request leaderboard from server
function RequestLeaderboard(category, limit)
    limit = limit or 10
    TriggerServerEvent('deepseafishing:server:getLeaderboards', category, limit)
end

-- Receive leaderboard data
RegisterNetEvent('deepseafishing:client:receiveLeaderboards', function(category, leaderboard)
    leaderboardData[category] = leaderboard
    DisplayLeaderboard(category)
end)

-- Request player ranking
function RequestPlayerRanking(category)
    TriggerServerEvent('deepseafishing:server:getPlayerRanking', category)
end

-- Receive player ranking
RegisterNetEvent('deepseafishing:client:receivePlayerRanking', function(category, ranking, value)
    playerRanking[category] = { ranking = ranking, value = value }
end)

-- Display leaderboard in chat
function DisplayLeaderboard(category)
    if not leaderboardData[category] then return end
    
    local data = leaderboardData[category]
    local title = ''
    local typeLabel = ''
    
    if category == 'earnings' then
        title = '💰 TOP EARNERS LEADERBOARD'
        typeLabel = 'earnings'
    elseif category == 'catches' then
        title = '🎣 TOP CATCHERS LEADERBOARD'
        typeLabel = 'catches'
    elseif category == 'heaviest' then
        title = '⚖️ HEAVIEST FISH LEADERBOARD'
        typeLabel = 'heaviest'
    elseif category == 'rarity' then
        title = '👑 LEGENDARY CATCHES LEADERBOARD'
        typeLabel = 'rarity'
    end
    
    TriggerEvent('chat:addMessage', {
        args = { title },
        color = { 0, 255, 100 }
    })
    
    for rank, entry in ipairs(data) do
        local message = Leaderboards.FormatEntry(rank, entry, typeLabel)
        TriggerEvent('chat:addMessage', {
            args = { message },
            color = { 255, 255, 255 }
        })
    end
    
    if playerRanking[category] then
        local myRank = playerRanking[category].ranking
        local myValue = playerRanking[category].value
        local myMessage = ''
        
        if myRank == 0 then
            myMessage = '^1You are not ranked yet^7'
        else
            if typeLabel == 'earnings' then
                myMessage = ("^3Your Ranking: #%d - $%s^7"):format(myRank, string.format("%,d", myValue))
            elseif typeLabel == 'catches' then
                myMessage = ("^3Your Ranking: #%d - %d catches^7"):format(myRank, myValue)
            elseif typeLabel == 'heaviest' then
                myMessage = ("^3Your Ranking: #%d - %.1f kg^7"):format(myRank, myValue)
            elseif typeLabel == 'rarity' then
                myMessage = ("^3Your Ranking: #%d - %d legendary^7"):format(myRank, myValue)
            end
        end
        
        TriggerEvent('chat:addMessage', {
            args = { myMessage },
            color = { 255, 200, 0 }
        })
    end
end

-- Display leaderboard menu
function DisplayLeaderboardMenu()
    local menu = {
        {
            label = '💰 Top Earners',
            description = 'View players with highest total earnings',
            onSelect = function()
                RequestLeaderboard('earnings', 10)
                RequestPlayerRanking('earnings')
                lib.notify({
                    title = 'Leaderboard',
                    description = 'Loading top earners...',
                    type = 'info',
                    duration = 2000
                })
            end
        },
        {
            label = '🎣 Top Catchers',
            description = 'View players with most fish caught',
            onSelect = function()
                RequestLeaderboard('catches', 10)
                RequestPlayerRanking('catches')
                lib.notify({
                    title = 'Leaderboard',
                    description = 'Loading top catchers...',
                    type = 'info',
                    duration = 2000
                })
            end
        },
        {
            label = '⚖️ Heaviest Fish',
            description = 'View largest fish caught by players',
            onSelect = function()
                RequestLeaderboard('heaviest', 10)
                RequestPlayerRanking('heaviest')
                lib.notify({
                    title = 'Leaderboard',
                    description = 'Loading heaviest fish records...',
                    type = 'info',
                    duration = 2000
                })
            end
        },
        {
            label = '👑 Legendary Catches',
            description = 'View most legendary fish caught',
            onSelect = function()
                RequestLeaderboard('rarity', 10)
                RequestPlayerRanking('rarity')
                lib.notify({
                    title = 'Leaderboard',
                    description = 'Loading legendary records...',
                    type = 'info',
                    duration = 2000
                })
            end
        }
    }
    
    if Config.Menus.style == 'ox_lib' then
        lib.registerContext({
            id = 'leaderboards_menu',
            title = '🏆 LEADERBOARDS',
            options = menu
        })
        lib.showContext('leaderboards_menu')
    else
        -- QBCore menu fallback
        TriggerEvent('qb-menu:client:openMenu', menu)
    end
end

-- Command to view leaderboards
lib.addCommand({
    name = 'leaderboards',
    description = 'View fishing leaderboards',
    help = 'Shows top earners, catchers, heaviest fish, and legendary records',
    restricted = false,
    action = function()
        DisplayLeaderboardMenu()
    end
})

-- Add leaderboards option to main fishing menu (called from client.lua)
function AddLeaderboardsToMenu(options)
    table.insert(options, {
        label = '🏆 Leaderboards',
        description = 'View top players and records',
        icon = 'fa-solid fa-trophy',
        onSelect = function()
            DisplayLeaderboardMenu()
        end
    })
    return options
end

exports('AddLeaderboardsToMenu', AddLeaderboardsToMenu)
